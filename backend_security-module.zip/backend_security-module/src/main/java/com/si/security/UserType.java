package com.si.security;

/**
 * Constants for Spring User Type authorities.
 */
public enum UserType {
    USER,
    ADMIN,
    SUPER_ADMIN
}
