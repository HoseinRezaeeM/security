package com.si.security;

import com.si.security.jwt.TokenProvider;
import com.si.security.principal.UserPrincipal;
import com.si.security.utils.RSAKeyUtils;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.apache.commons.io.IOUtils;
import org.springframework.lang.Nullable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * Utility class for Spring Security.
 */
public final class SecurityUtils {
    private static final String PRIVATE_KEY;

    static {
        try {
            PRIVATE_KEY = IOUtils.toString(Objects.requireNonNull(SecurityUtils.class.getResourceAsStream("/certs/jwtRS256.key.pem")), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replace("\n", "");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private SecurityUtils() {
    }

    /**
     * Get the login of the current user.
     *
     * @return the login of the current user.
     */
    public static Optional<UserPrincipal> getCurrentUser() {
        var securityContext = SecurityContextHolder.getContext();
        return Optional.ofNullable((UserPrincipal) securityContext.getAuthentication().getPrincipal());
    }

    public static Optional<String> getCurrentUserString() {
        var securityContext = SecurityContextHolder.getContext();
        Optional<Object> o = Optional.ofNullable(securityContext.getAuthentication())
                .map(Authentication::getPrincipal);
        if (o.isPresent()) {
            Object principal = o.get();
            if (principal instanceof UserPrincipal) {
                UserPrincipal passengerPrincipal = (UserPrincipal) principal;
                return Optional.ofNullable(passengerPrincipal.toString());
            }
        }
        return Optional.empty();
    }

    public static Optional<String> getCurrentUserCellphone() {
        var securityContext = SecurityContextHolder.getContext();
        Optional<Object> o = Optional.ofNullable(securityContext.getAuthentication())
                .map(Authentication::getPrincipal);
        if (o.isPresent()) {
            Object principal = o.get();
            if (principal instanceof UserPrincipal) {
                var userPrincipal = (UserPrincipal) principal;
                return Optional.ofNullable(userPrincipal.getCellPhone());
            }
        }
        return Optional.empty();
    }

    @Nullable
    public static String getCurrentUserId() {
        return Objects.requireNonNull(getCurrentUser().orElse(null)).getId();
    }

    /**
     * Get the JWT of the current user.
     *
     * @return the JWT of the current user.
     */
    public static Optional<String> getCurrentUserJWT() {
        var securityContext = SecurityContextHolder.getContext();
        return Optional
                .ofNullable(securityContext.getAuthentication())
                .filter(authentication -> authentication.getCredentials() instanceof String)
                .map(authentication -> (String) authentication.getCredentials());
    }

    /**
     * Check if a user is authenticated.
     *
     * @return true if the user is authenticated, false otherwise.
     */
    public static boolean isAuthenticated() {
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && getAuthorities(authentication).noneMatch(AuthoritiesConstants.ANONYMOUS::equals);
    }

    /**
     * Checks if the current user has any of the authorities.
     *
     * @param authorities the authorities to check.
     * @return true if the current user has any of the authorities, false otherwise.
     */
    public static boolean hasCurrentUserAnyOfAuthorities(String... authorities) {
        var authentication = SecurityContextHolder.getContext().getAuthentication();
        return (
                authentication != null && getAuthorities(authentication).anyMatch(authority -> Arrays.asList(authorities).contains(authority))
        );
    }

    /**
     * Checks if the current user has none of the authorities.
     *
     * @param authorities the authorities to check.
     * @return true if the current user has none of the authorities, false otherwise.
     */
    public static boolean hasCurrentUserNoneOfAuthorities(String... authorities) {
        return !hasCurrentUserAnyOfAuthorities(authorities);
    }

    /**
     * Checks if the current user has a specific authority.
     *
     * @param authority the authority to check.
     * @return true if the current user has the authority, false otherwise.
     */
    public static boolean hasCurrentUserThisAuthority(String authority) {
        return hasCurrentUserAnyOfAuthorities(authority);
    }

    private static Stream<String> getAuthorities(Authentication authentication) {
        return authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority);
    }

    public static String getSystemToken() {
        return Jwts.builder()
                .setSubject(SystemAuthentication.SYSTEM)
                .claim(TokenProvider.TYPE, SystemAuthentication.SYSTEM)
                .signWith(RSAKeyUtils.getRSAPrivateKey(PRIVATE_KEY), SignatureAlgorithm.RS256)
                .compact();
    }

    public static void main(String[] args) {
        System.out.println(getSystemToken());
    }
}
