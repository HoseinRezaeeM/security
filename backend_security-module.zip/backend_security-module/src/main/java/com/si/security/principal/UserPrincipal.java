package com.si.security.principal;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class UserPrincipal {
    private String id;
    private String fullName;
    private String cellPhone;
    private Long org;
    private Long customerId;
    private String photoURL;
    private String email;
}
