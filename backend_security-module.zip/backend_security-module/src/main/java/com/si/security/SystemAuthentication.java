package com.si.security;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collections;
import java.util.List;

public class SystemAuthentication extends AbstractAuthenticationToken {
    private final static List<GrantedAuthority> defaultAuthorities =
            Collections.singletonList(new SimpleGrantedAuthority(AuthoritiesConstants.SYSTEM));
    public static final String SYSTEM = "system";

    /**
     * Creates a token with the supplied array of authorities.
     */
    public SystemAuthentication() {
        super(defaultAuthorities);
    }

    @Override
    public Object getCredentials() {
        return SYSTEM;
    }

    @Override
    public Object getPrincipal() {
        return SYSTEM;
    }
}