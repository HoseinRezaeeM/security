package com.si.security.mapper;

import com.si.security.principal.UserPrincipal;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

public class UserTokenMapperImpl implements UserTokenMapper<UserPrincipal> {

    @Override
    public UserPrincipal userFromClaims(Claims claims) {
        UserPrincipal userPrincipal = new UserPrincipal();
        userPrincipal.setId((String) claims.get("sub"));
        userPrincipal.setEmail((String) claims.get("email"));
        userPrincipal.setFullName((String) claims.get("name"));
        userPrincipal.setCellPhone((String) claims.get("preferred_username"));
        if (claims.get("org") != null) {
            userPrincipal.setOrg(Long.parseLong(String.valueOf(claims.get("org"))));
        }
        if (claims.get("customerId") != null) {
            userPrincipal.setCustomerId(Long.parseLong(String.valueOf(claims.get("customerId"))));
        }
        userPrincipal.setPhotoURL((String) claims.get("photo_url"));
        return userPrincipal;
    }

    @Override
    public Claims generateClaims(UserPrincipal user) {
        Claims claims = Jwts.claims();
        claims.put("id", user.getId());
        claims.put("name", user.getFullName());
        claims.put("cellPhone", user.getCellPhone());
        claims.put("photoUrl", user.getPhotoURL());
        claims.put("sub", user.getId());
        claims.setSubject(user.getId());
        return claims;
    }

    @Override
    public Class<UserPrincipal> getType() {
        return UserPrincipal.class;
    }

    @Override
    public String getTypeStr() {
        return "user";
    }
}
