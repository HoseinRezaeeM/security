package com.si.security.jwt;

import com.si.security.SecurityUtils;
import com.si.security.SystemAuthentication;
import com.si.security.mapper.UserTokenMapper;
import com.si.security.mapper.UserTokenMapperImpl;
import com.si.security.principal.UserPrincipal;
import com.si.security.utils.RSAKeyUtils;
import io.jsonwebtoken.*;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class TokenProvider {

    public static final String TYPE = "type";
    private static final String AUTHORITIES_KEY = "auth";
    private static final String INVALID_JWT_TOKEN = "Invalid JWT token.";
    private static final String PUBLIC_KEY;
    private static final String PRIVATE_KEY;

    static {
        try {
            PRIVATE_KEY = IOUtils.toString(Objects.requireNonNull(SecurityUtils.class.getResourceAsStream("/certs/jwtRS256.key.pem")), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .replace("\n", "")
                    .replace("\r", "");

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    static {
        try {
            PUBLIC_KEY = IOUtils.toString(Objects.requireNonNull(SecurityUtils.class.getResourceAsStream("/certs/public.pem")), StandardCharsets.UTF_8)
                    .replace("\n", "");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private final Logger log = LoggerFactory.getLogger(TokenProvider.class);
    private final JwtParser jwtParser;
    private final UserTokenMapper<UserPrincipal> userTokenMapper = new UserTokenMapperImpl();

    @Autowired
    public TokenProvider() throws Exception {
        jwtParser = Jwts.parserBuilder()
                .setSigningKey(RSAKeyUtils.getRSAPublicKey(PUBLIC_KEY))
                .build();
    }

    public String createToken(Authentication authentication, String type, Integer tokenValidityInSeconds) {
        String authorities = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority).collect(Collectors.joining(","));

        long now = (new Date()).getTime();
        Date validity = new Date(now + tokenValidityInSeconds * 1000);

        Claims claims = userTokenMapper.generateClaims((UserPrincipal) authentication.getPrincipal());
        claims.put(TYPE, type);

        claims.put(AUTHORITIES_KEY, authorities);
        return Jwts
                .builder()
                .addClaims(claims)
                .signWith(RSAKeyUtils.getRSAPrivateKey(PRIVATE_KEY), SignatureAlgorithm.RS256)
                .setExpiration(validity)
                .compact();
    }

    public Authentication getAuthentication(String token) {
        Claims claims = jwtParser.parseClaimsJws(token).getBody();

        String type = (String) claims.get(TYPE);
        if (type != null && type.equals("system"))
            return new SystemAuthentication();

        String authString = claims.get(AUTHORITIES_KEY).toString();
        if (!StringUtils.hasText(authString))
            throw new RuntimeException();

        Collection<? extends GrantedAuthority> authorities = Arrays
                .stream(authString.replace("[", "").replace("]", "").split("\\s*,\\s*"))
                .filter(auth -> !auth.trim().isEmpty())
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());

        UserPrincipal principal = userTokenMapper.userFromClaims(claims);

        return new UsernamePasswordAuthenticationToken(principal, token, authorities);
    }

    public boolean validateToken(String authToken) {
        try {
            jwtParser.parseClaimsJws(authToken);
            return true;
            // TODO: should we let it bubble (no catch), to avoid defensive programming and follow the fail-fast principle?
        } catch (Exception e) {
            log.error("Token validation error {}", e.getMessage());
        }
        return false;
    }

    public String addNewClaimsToAccessToken(String accessToken, Map<String, Object> newClaims) {
        Jws<Claims> claimsJws = jwtParser.parseClaimsJws(accessToken);
        JwsHeader<?> header = claimsJws.getHeader();
        Claims bodyClaims = claimsJws.getBody();
        bodyClaims.putAll(newClaims);
        return Jwts
                .builder()
                .setHeader(header.entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)))
                .addClaims(bodyClaims)
                .signWith(RSAKeyUtils.getRSAPrivateKey(PRIVATE_KEY), SignatureAlgorithm.RS256)
                .compact();
    }
}
