package com.si.security.mapper;

import com.si.security.principal.UserPrincipal;
import io.jsonwebtoken.Claims;

public interface UserTokenMapper<T extends UserPrincipal> {
    T userFromClaims(Claims claims);
    Claims generateClaims(UserPrincipal user);
    Class<T> getType();
    String getTypeStr();
}